# Corner Restaurant, Austin – website redesign concept

Unofficial concept. Menu items and prices are placeholders.

## Run locally
Open `index.html` in any browser (double-click it).
Optional local server: `python3 -m http.server 8000` then visit http://localhost:8000

## Edit
- Menu: edit the `MENU` object near the bottom of `index.html`.
- Colors: edit the CSS variables at the top of the `<style>` block.
- Contact, hours, links: edit the "Visit us" section and footer.

## Verified details used
Address 110 E 2nd St, Austin, TX 78701; phone (512) 608-4488; hours per Marriott dining page;
Taco Tuesday and weekend brunch per OpenTable; Instagram @corneratx; Facebook CornerATX.

## Deploy
Upload `index.html` to any static host (Netlify, Vercel, GitHub Pages).
